<?php
session_start();
if ($_GET['id']=='guru') {
	unset($_SESSION['guru']);
	unset($_SESSION['id']);
}else{
	unset($_SESSION['admin']);
	unset($_SESSION['id_admin']);
}

header("location: index.php");

?>