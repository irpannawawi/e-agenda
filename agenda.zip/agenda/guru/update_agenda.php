<?php
require '../database.php';
	$id = $_POST['id'];
	$text = $_POST['text'];
	if (empty($text)) {
		
		$sql = "UPDATE agenda SET kompetensi_dasar = '', kehadiran='' where id_agenda='$id' ";
		if ($conn->query($sql)) {
			header("location: guru.php");
		}else{
			echo $conn->error;
		}
		header("location: guru.php");
		die;
	}

	
	$sql = "UPDATE agenda SET kompetensi_dasar = '$text', kehadiran='0' where id_agenda='$id' ";
	$conn->query($sql);

	if ($conn->query($sql)) {
		header("location: guru.php");
	}else{
		echo $conn->error;
	}

?>