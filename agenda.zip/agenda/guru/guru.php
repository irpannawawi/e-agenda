<?php 
session_start();

require '../database.php';
$tanggal = date('d/m/Y');

$sql = "SELECT * FROM agenda WHERE tanggal = '$tanggal' ";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Guru | E-Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({
  dateFormat: "dd/mm/yy"
});
  } );
  </script>
</head>


<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  		<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['guru']); ?></h1></a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
    			<a class="nav-item nav-link active" href="guru.php">Home</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=guru" style="color: red;">Keluar</a>
   			</div>
  		</div>
	</nav>

<div class="row" style="margin-left: 10px; margin-top: 15px;">
	<div class="col-lg-4 col-md-4">
		<?php if($result->num_rows>1){ ?>
		<table class="table table-bordered">
			<tr>
				<td colspan="3">
					<input type="search" class="tanggal " id="datepicker"><input type="submit" name="submit" value="Cari" class="searchBtn">
				</td>
				<td colspan="3">Tanggal : <?php echo date('d/m/Y'); ?></td>
			</tr>
		</table>

		<table class="display table table-bordered table-striped">
		<tr style="background: #bfbfbf;">
			<th>Jam</th>
			<th>Nama</th>
			<th>Mata Pelajaran</th>
			<th>Kompetensi Dasar</th>
			<th>Aksi</th>
		</tr>
		
		<?php while($row = $result->fetch_assoc()){ ?>
			<tr>
				<td><?php echo $row['jam']; ?></td>
				<td><?php echo $row['nama_guru']; ?></td>
				<td><?php echo $row['mapel']; ?></td>
				<form action="update_agenda.php" method="post">
					<td>

						<?php if (!empty($row['kompetensi_dasar'])) {
							echo $row['kompetensi_dasar'];
						}else{ ?>
						<textarea name="text" <?php if($_SESSION['id'] != $row['id_guru']){ echo "disabled"; } ?> ></textarea>
					<?php } ?>
						<input type="id" name="id" value="<?php echo $row['id_agenda']; ?>" hidden>
					</td>
					<td>
						<?php if (!empty($row['kompetensi_dasar'])){ ?>
						 	<button class="btn btn-danger">Batal</button> 
						<?php }else{ ?>
							<button class="btn btn-success">Simpan</button> 
						<?php } ?>
					</td>
				</form>
			</tr>
		<?php } ?>
	</table>
	</table>
	<?php }else{ ?>
		<h2 align="center">Sekertaris Belum memulai !!</h2>
	<?php } ?>
	</div>
</div>
	
	





	<script type="text/javascript">
		$(document).ready(function(){
			$('.searchBtn').click(function(){
				var searchVal = $('.tanggal').val();
				$.post('search.php',{search:searchVal},function(data){
					$('.display').html(data);
				});
			});
		})
	</script>
</body>
</html>