<?php
	
	require_once '../database.php';

	$username	= $_POST['username'];
	$password 	= $_POST['password'];

	$sql		= "SELECT * FROM guru WHERE nama_guru = '$username' && password = '$password' ";
	$result 	= $conn->query($sql);
	$data 		= $result->fetch_assoc();
	if ($result->num_rows < 1) {
		header("location:index.php");
	}else{
		session_start();
		$_SESSION['guru'] = $username;
		$_SESSION['id'] = $data['id_guru'];
		header('location:guru.php');
	}

?>