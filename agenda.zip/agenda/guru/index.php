
<?php 
session_start();
require_once '../database.php';
if (isset($_SESSION['guru'])) {
  header('location: guru.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/style.css">
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
</head>
<body>

<div class="login-page">
  	<div class="form">
  		<h1 align="center">Login</h1>
    	<form class="login-form" method="post" action="login.php">
      		<input type="text" placeholder="username" name="username" />
      		<input type="password" placeholder="password" name="password" />
      		<button>login</button>
   		</form>
	</div>
</div>
</body>
</html>