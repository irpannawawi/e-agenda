<?php 
session_start();
require_once '../database.php';
if (isset($_SESSION['admin'])) {
  header('location: admin.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/style.css">
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>

</head>
<body>
<div class="login-page">
  <div class="form">
    <form class="login-form" method="post" action="login.php">
      <input type="text" placeholder="username" name="username" />
      <input type="password" placeholder="password" name="password" />
      <button>login</button>
    </form>
  </div>
</div>


</body>
</html>