<?php
	$tanggal = $_POST['search'];
	require '../database.php';
	$sql = "SELECT * FROM agenda WHERE tanggal = '$tanggal' ";
	$res = $conn->query($sql);



?>
		<tr style="background: #bfbfbf;">
			<th>Jam</th>
			<th>Nama</th>
			<th>Mata Pelajaran</th>
			<th>Kompetensi Dasar</th>
			<th>Kehadiran</th>
		</tr>
<?php



	while ($row = $res->fetch_assoc()) {
		if ($row['kehadiran']==='0') {
			$kehadiran = "pending";
		}elseif ($row['kehadiran']==='1') {
			$kehadiran = "Hadir";
		}
		echo '<tr>';

		echo '<td>'.$row['jam'].'</td>';
		echo '<td>'.$row['nama_guru'].'</td>';
		echo '<td>'.$row['mapel'].'</td>';
		echo '<td>'.$row['kompetensi_dasar'].'</td>';
		echo '<td>'.$kehadiran.'</td>';
		echo '</tr>';
		
	}
?>