<?php
	require '../database.php';
	$id = $_GET['id'];

	$sql = "UPDATE agenda SET kehadiran = '1' WHERE id_agenda='$id' ";
	$conn->query($sql);

	header("location: admin.php");
?>