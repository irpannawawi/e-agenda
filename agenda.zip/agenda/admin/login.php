<?php
	
	require_once '../database.php';

	$username	= $_POST['username'];
	$password 	= $_POST['password'];

	$sql		= "SELECT * FROM admin WHERE username = '$username' && password = '$password'";
	$result 	= $conn->query($sql);
	$data 		= $result->fetch_assoc();
	echo $conn->error;
	if ($result->num_rows < 1) {
		//header("location:index.php");
		echo $conn->error;
	}else{
		session_start();
		$_SESSION['admin'] = $username;
		$_SESSION['id_admin'] = $data['id_user'];
		header('location:admin.php');
	}

?>