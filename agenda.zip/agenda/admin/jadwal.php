<?php
	session_start();
	require_once '../database.php';
	$sql = "SELECT * FROM jadwal";
	$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin | Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
</head>
<body>
	<div class="menu">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
  			<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['admin']); ?></h1></a>
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
	    	  	<a class="nav-item nav-link active" href="admin.php">Home</a>
	      		<a class="nav-item nav-link" href="jadwal.php">Jadwal Pelajaran</a>
	      		<a class="nav-item nav-link" href="tambah_akun.php">Tambah Akun</a>
	      		<a class="nav-item nav-link" href="deploy_agenda.php">Deploy Agenda</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=admin">Keluar</a>
   			 </div>
  			</div>
		</nav>
	</div>

	<h1 style="margin-left: 10px; margin-top: 15px;">Jadwal Pelajaran</h1>
	<div class="btn-group"style="margin-left: 10px; margin-top: 15px;">
		<button class="btn btn-sm btn-success">
			<a href="tambah_jadwal.php" style="color: white;">Tambah Jadwal</a>
		</button>
		<button class="btn btn-sm btn-danger">
			<a href="admin.php" style="color: white;">Kembali</a>			
		</button>
	</div>
<div class="row" style="margin-left: 10px; margin-top: 15px;">
	<div class="col-lg-5 col-md-5">
		<table class="table table-striped table-hover">
		<tr style="background: #bfbfbf;">
			<th>No</th>
			<th>Nama Guru</th>
			<th>Mata Pelajaran</th>
			<th>Jam Ke</th>
			<th>Hari</th>
			<th>Aksi</th>
		</tr>
		
		<?php $n=0; while($row = $result->fetch_assoc()){ $n++; ?>
		<tr>
			<td><?php echo $n; ?></td>
			<td><?php echo $row['nama_guru']; ?></td>
			<td><?php echo $row['mapel']; ?></td>
			<td><?php echo $row['jam']; ?></td>
			<td><?php echo $row['hari']; ?></td>
			<td><a href="hapus_jadwal.php?id=<?php echo $row['id_jadwal']; ?>">Hapus</a></td>
		</tr>
		<?php } ?>

	</table>
	</div>
</div>
	

</body>
</html>