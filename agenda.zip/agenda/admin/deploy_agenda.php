<?php 
session_start();
require_once '../database.php';
$hari_ini = date('l');
switch ($hari_ini) {
	case 'Sunday':
		$hari_ini = 'Minggu';
		break;
	case 'Monday':
		$hari_ini = 'Senin';
		break;
	case 'Tuesday':
		$hari_ini = 'Selasa';
		break;
	case 'Wednesday':
		$hari_ini = 'Rabu';
		break;
	case 'Thursday':
		$hari_ini = 'Kamis';
		break;
	case 'Friday':
		$hari_ini = 'Jumat';
		break;
	case 'Saturday':
		$hari_ini = 'Sabtu';
		break;
	default:
		# code...
		break;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN | E-Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  		<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['admin']); ?></h1></a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
	    	  	<a class="nav-item nav-link active" href="admin.php">Home</a>
	      		<a class="nav-item nav-link" href="jadwal.php">Jadwal Pelajaran</a>
	      		<a class="nav-item nav-link" href="tambah_akun.php">Tambah Akun</a>
	      		<a class="nav-item nav-link" href="deploy_agenda.php">Deploy Agenda</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=admin">Keluar</a>
   			</div>
  		</div>
	</nav>
<div class="row" style="margin: auto;">
	<div class="col-lg-4 col-md-4">
				<h2>Agenda Hari Ini <?php echo date('d/m/Y'); ?></h2>
		<table class="table table-bordered table-hover table-sriped">
			
			<tr style="background: #bfbfbf;">
				<th>Jam ke</th>
				<th>Nama Guru</th>
				<th>Mata Pelajaran</th>
			</tr>
			
			<form >
				<?php
					$sql = "SELECT * FROM jadwal WHERE hari = '$hari_ini' ";
					$result = $conn->query($sql);
					while ($row = $result->fetch_assoc()) {
				?>
			<tr>
				<td><?php echo $row['jam']; ?></td>
				<td><?php echo $row['nama_guru']; ?></td>
				<td><?php echo $row['mapel']; ?></td>

			</tr>	
				<?php	} ?>
			<tr>
				<td colspan="3" align="center">
					<?php 
						$tanggal = date('d/m/Y');
						$sql= "SELECT * FROM agenda WHERE tanggal = '$tanggal'";
						$res = $conn->query($sql);
						if($res->num_rows > 1){
							echo "Sudah di deploy untuk hari ini.<a href='admin.php' >Kembali</a>";
						}else{
					 ?>
					<a href="insert_agenda.php" class="btn btn-success">Deploy</a>
				<?php } ?>
				</td>
			</tr>
			<tr>
				<td colspan="3">
					<a href="reset_agenda.php" class="btn btn-danger">Reset</a>
				</td>
			</tr>
			</form>
				
		</table>
	</div>
</div>

		

	</body>
</html>