<?php
	require_once '../database.php';

	$level = $_POST['level'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	if ($level == 'Admin') {
		$sql = "INSERT INTO admin(username,password) VALUES('$username','$password')";
	}elseif ($level == 'Guru') {
		$sql = "INSERT INTO guru(nama_guru,password) VALUES('$username','$password')";
	}
	$conn->query($sql);
	header("location: tambah_akun.php");
?>