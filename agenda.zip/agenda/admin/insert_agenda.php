<?php
	require '../database.php';
	$hari_ini = date('l');
	switch ($hari_ini) {
		case 'Sunday':
			$hari_ini = 'Minggu';
			break;
		case 'Monday':
			$hari_ini = 'Senin';
			break;
		case 'Tuesday':
			$hari_ini = 'Selasa';
			break;
		case 'Wednesday':
			$hari_ini = 'Rabu';
			break;
		case 'Thursday':
			$hari_ini = 'Kamis';
			break;
		case 'Friday':
			$hari_ini = 'Jumat';
			break;
		case 'Saturday':
			$hari_ini = 'Sabtu';
			break;
		default:
			# code...
			break;
	}
	$select = "SELECT * FROM jadwal WHERE hari = '$hari_ini' ";
	$result = $conn->query($select);

	while ($row = $result->fetch_assoc()) {
		$id = $row['id_guru'];
		$jam = $row['jam'];
		$nama = $row['nama_guru'];
		$mapel = $row['mapel'];
		$tanggal = date('d/m/Y');
		$sql = "INSERT INTO agenda(id_guru, jam, nama_guru, mapel, tanggal) VALUES('$id', '$jam', '$nama', '$mapel', '$tanggal')";
		$res = $conn->query($sql);
		header("location: deploy_agenda.php");
	}
	
?>