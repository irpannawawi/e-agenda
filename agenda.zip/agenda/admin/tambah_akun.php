<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin | E-Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  		<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['admin']); ?></h1></a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
	    	  	<a class="nav-item nav-link active" href="admin.php">Home</a>
	      		<a class="nav-item nav-link" href="jadwal.php">Jadwal Pelajaran</a>
	      		<a class="nav-item nav-link" href="tambah_akun.php">Tambah Akun</a>
	      		<a class="nav-item nav-link" href="deploy_agenda.php">Deploy Agenda</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=admin">Keluar</a>
   			</div>
  		</div>
	</nav>
<div class="row" style="margin-left: 10px; margin-right: 10px; margin-bottom: 15px;">
	<div class="col-lg-3 col-md-3">
		<h1>Tambah Akun</h1>
		<form action="insert_akun.php" method="post">
			<table>
				<tr>
					<td>Username : </td>
					<td><input type="text" name="username"></td>
				</tr>
				<tr>
					<td>Password : </td>
					<td><input type="text" name="password"></td>
				</tr>
				<tr>
					<td>Level : </td>
					<td>
						<select name="level">
							<option value="Admin">Admin</option>
							<option value="Guru">Guru</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="Tambah" class="btn btn-sm btn-success"></td>
					<td><a href="admin.php">Kembali</a></td>
				</tr>
		
			</table>
		</form>
	</div>
	<div class="col-lg-3 col-md-3">
		<?php 
require '../database.php';
	$sql_admin = "SELECT * FROM admin";
	$sql_guru = "SELECT * FROM guru";
	$result_admin = $conn->query($sql_admin);
	$result_guru = $conn->query($sql_guru);
?>
		<h2>Admin</h2>
		<table id="admin" class="table table-striped table-hover table-bordered">
			
		<tr style="background: #bfbfbf;">
			<th>No</th>
			<th>Nama</th>
			<th>Password</th>
		</tr>
		<?php $n = 0;
			while ($a = $result_admin->fetch_assoc()) { $n++;
		?>
		<tr>
			<td><?php echo $n; ?></td>
			<td><?php echo $a['username']; ?></td>
			<td><?php echo $a['password']; ?></td>
		</tr>

	<?php } ?>
	</table>


	</div>
	<div class="col-lg-6 col-md-6">
		<h2>Guru</h2>
	<table id="guru" class="table table-striped table-hover table-bordered">
		
		<tr style="background: #bfbfbf;">
			<th>No</th>
			<th>Id</th>
			<th>Nama</th>
			<th>Password</th>
		</tr>
		<?php $x = 0;
			while ($b = $result_guru->fetch_assoc()) { $x++;
		?>
		<tr>
			<td><?php echo $n; ?></td>
			<td><?php echo $b['id_guru']; ?></td>
			<td><?php echo $b['nama_guru']; ?></td>
			<td><?php echo $b['password']; ?></td>
		</tr>

	<?php } echo $conn->error; ?>
	</table>
	</div>
</div>

	

	
</body>
</html>