<?php
	$id 	= $_POST['id_guru'];
	$nama 	= $_POST['nama_guru'];
	$mapel 	= $_POST['mata_pelajaran'];
	$jam	= $_POST['jam_ke'];
	$hari 	= $_POST['hari'];

	require '../database.php';
	$sql_checker = "SELECT * FROM jadwal WHERE jam ='".$jam."' && hari = '".$hari."'";

	$result = $conn->query($sql_checker);
	if($result->num_rows >= 1){ 
		echo "data sudah ada"; 
		die; 
	}

	$sql = "INSERT INTO jadwal (id_guru, nama_guru, mapel, jam, hari) VALUES('$id','$nama','$mapel','$jam','$hari')";

	if($conn->query($sql)){
		header("location: tambah_jadwal.php?msg=1");
	}else{
		echo "failed".$conn->error;
	}
?>