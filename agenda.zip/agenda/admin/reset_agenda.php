<?php
	require '../database.php';
	$tanggal = date('d/m/Y');
	$sql = "DELETE FROM agenda WHERE tanggal = '$tanggal' ";
	$conn->query($sql);
	header("location: deploy_agenda.php");
?>