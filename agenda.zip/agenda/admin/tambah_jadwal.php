<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin | E-Agenda</title>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
</head>
<body>
<div class="menu">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
  			<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['admin']); ?></h1></a>
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
	    	  	<a class="nav-item nav-link active" href="admin.php">Home</a>
	      		<a class="nav-item nav-link" href="jadwal.php">Jadwal Pelajaran</a>
	      		<a class="nav-item nav-link" href="tambah_akun.php">Tambah Akun</a>
	      		<a class="nav-item nav-link" href="deploy_agenda.php">Deploy Agenda</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=admin">Keluar</a>
   			 </div>
  			</div>
		</nav>
	</div>
<div class="row" style="margin-left: 10px; margin-right: 10px; margin-bottom: 15px;">
	<div class="col-md-3 col-lg-3">
		<h2>Tambah Jadwal</h2>
		<?php
		if (isset($_GET['msg'])) {
			echo '<p align="center">Berhasil tambah data!</p>';
		}
	?>
<!--Form isian-->
	<form action="insert_jadwal.php" method="post">
	<table >
		<tr>
			<td>Id Guru :</td>
			<td><input type="text" name="id_guru"></td>
		</tr>
		<tr>
			<td>Nama Guru :</td>
			<td><input type="text" name="nama_guru"></td>
		</tr>
		<tr>
			<td>Mata Pelajaran :</td>
			<td><input type="text" name="mata_pelajaran"></td>
		</tr>
		<tr>
			<td>Jam Ke :</td>
			<td><input type="text" name="jam_ke"></td>
		</tr>
		<tr>
			<td>Hari :</td>
			<td><input type="text" name="hari"></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="Tambah" class="btn btn-success"></td>
			<td><a href="jadwal.php">Kembali</a></td>
		</tr>
	</table>
	</form>
<!--END Form isian-->
	</div>
	<div class="col-md-3 col-lg-3">
		<!--SELECT DATA FROM DB-->
<?php
require '../database.php';
$sql_guru = "SELECT * FROM guru";
$result_guru = $conn->query($sql_guru);
?>
<!--END SELECT DATA FROM DB-->
<!--TABEL DATA GURU-->
	<h2>Guru</h2>
	<table id="guru" class="table table-striped table-hover table-bordered">
		<tr style="background: #bfbfbf;">
			<th>No</th>
			<th>Id</th>
			<th>Nama</th>
			
		</tr>
		<?php $x = 0;
			while ($b = $result_guru->fetch_assoc()) { $x++;
		?>
		<tr>
			<td><?php echo $x; ?></td>
			<td><?php echo $b['id_guru']; ?></td>
			<td><?php echo $b['nama_guru']; ?></td>
		</tr>

	<?php } echo $conn->error; ?>
	</table>
<!--END TABEL DATA GURU-->
	</div>
	<div class="col-md-6 col-lg-6">
		<!--TABEL JADWAL-->
<?php
	$sql= "SELECT * FROM jadwal";
	$res = $conn->query($sql);
?>
	<h2>Jadwal</h2>
	<table id="jadwal" class="table table-striped table-hover table-bordered">
		
		<tr style="background: #bfbfbf;">
			<th>No</th>
			<th>Id Guru</th>
			<th>Mata Pelajaran</th>
			<th>Nama</th>
			<th>Jam</th>
			<th>Hari</th>
		</tr>
		<?php $n = 0;  while ($row = $res->fetch_assoc()) { $n++; ?>
			<tr>
				<td><?php echo $n; ?></td>
				<td><?php echo $row['id_guru']; ?></td>
				<td><?php echo $row['nama_guru']; ?></td>
				<td><?php echo $row['mapel']; ?></td>
				<td><?php echo $row['jam']; ?></td>
				<td><?php echo $row['hari']; ?></td>
			</tr>
			
		<?php } ?>
	</table>
<!--END TABEL JADWAL-->
	</div>
</div>

	
	



</body>
</html>