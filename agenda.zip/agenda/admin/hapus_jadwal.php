<?php
require '../database.php';

$sql= "DELETE FROM jadwal where id_jadwal= '".$_GET['id']."' ";
if($conn->query($sql)){
	header("location: jadwal.php");
}else{
	echo $conn->error;
}
?>