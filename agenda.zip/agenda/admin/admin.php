<?php 
session_start();
require_once '../database.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN | E-Agenda</title>
	<style type="text/css">
		ul{
			list-style: none;
			display: block;
		}
	</style>
	<link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="../style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="../style/jquery-ui/jquery-ui.js"></script>
 	<script>
  		$( function() {
    		$( "#datepicker" ).datepicker({
				dateFormat: "dd/mm/yy"
			});
  		} );
  	</script>
</head>
<body>
	

	<div class="menu">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
  			<a class="navbar-brand" href="#"><h1><?php echo strtoupper($_SESSION['admin']); ?></h1></a>
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>
  		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
	    	  	<a class="nav-item nav-link active" href="admin.php">Home</a>
	      		<a class="nav-item nav-link" href="jadwal.php">Jadwal Pelajaran</a>
	      		<a class="nav-item nav-link" href="tambah_akun.php">Tambah Akun</a>
	      		<a class="nav-item nav-link" href="deploy_agenda.php">Deploy Agenda</a>
	      		<a class="nav-item nav-link" href="../logout.php?id=admin">Keluar</a>
   			 </div>
  			</div>
		</nav>
	</div>
	<div class="row">
		<div class="col-lg-5 col-md-5" style="margin-top: 15px; margin-left: 10px;">
			<h2>Agenda Kelas</h2>
<!--Table 1 -->
			<table class="table table-bordered table-sm">
			<tr>
				<td>
					<div class="input-group mb-3">
    					<input type="search" class="tanggal form-control " id="datepicker">
    					<div class="input-group-append">
      						<input type="submit" name="submit" value="Cari" class="searchBtn btn btn-primary form-control">
   					 	</div>
  					</div>
				</td>
				<td>Tanggal : <?php echo date('d/m/Y'); ?></td>
			</tr>
		</table>
<!--Table 2 -->
		<table class="display table table-bordered">
			<tr style="background: #bfbfbf;">
				<th>Jam ke</th>
				<th>Nama Guru</th>
				<th>Mata Pelajaran</th>
				<th>Kompetensi dasar</th>
				<th>Kehadiran</th>
			</tr>
			
			<form>
				<?php
					$tanggal = date('d/m/Y');
					$sql = "SELECT * FROM agenda WHERE tanggal = '$tanggal' ";
					$result = $conn->query($sql);
					while ($row = $result->fetch_assoc()) {
				?>



			<tr>
				<td><?php echo $row['jam']; ?></td>
				<td><?php echo $row['nama_guru']; ?></td>
				<td><?php echo $row['mapel']; ?></td>
				<td><?php echo $row['kompetensi_dasar']; ?></td>
				<td>
					<?php if($row['kehadiran'] === '0'){ ?>
						<button class="btn btn-sm btn-success"><a href="approve.php?id=<?php echo $row['id_agenda']; ?>" style="color: white;">Approve</a></button>
					<?php }elseif ($row['kehadiran'] === '1') {
						echo "Hadir";					} ?>
				</td>
			</tr>	


				<?php	} ?>

			</form>
				
		</table>

		</div>
	</div>
		
		
		
	

	<script type="text/javascript">
		$(document).ready(function(){
			$('.searchBtn').click(function(){
				var searchVal = $('.tanggal').val();
				$.post('search.php',{search:searchVal},function(data){
					$('.display').html(data);
				});
			});
		})
	</script>
	</body>
</html>