<?php
	require 'database.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>E-Agenda</title>
	<link rel="stylesheet" type="text/css" href="style/css/bootstrap.min.css">
	<link rel="stylesheet" href="style/jquery-ui/jquery-ui.css">
  	<link rel="stylesheet" href="/resources/demos/style.css">
  	<script src="style/jquery-ui/external/jquery/jquery.js"></script>
 	<script src="style/jquery-ui/jquery-ui.js"></script>
</head>
<body>
<div class="d-flex bg-light">
	<h2>Agenda kelas hari ini <?php echo date('d/m/Y'); ?></h2>
  	<div class="p-2 bg-light"><a href="admin/index.php">Admin</a></div>
  	<div class="p-2 bg-light"><a href="guru/index.php">Guru</a></div>
  	
</div>
	
	<div class="row">
		<div class="col-lg-6">
			<table class="display table table-bordered">
			<tr style="background: #bfbfbf;">
				<th>Jam ke</th>
				<th>Nama Guru</th>
				<th>Mata Pelajaran</th>
				<th>Kompetensi dasar</th>
				<th>Kehadiran</th>
			</tr>
			
			<form>
				<?php
					$tanggal = date('d/m/Y');
					$sql = "SELECT * FROM agenda WHERE tanggal = '$tanggal' ";
					$result = $conn->query($sql);
					while ($row = $result->fetch_assoc()) {

						if ($row['kehadiran']==='0') {
							$kehadiran = "pending";
							$warna = "red";
						}elseif ($row['kehadiran']==='1') {
							$kehadiran = "Hadir";
							$warna = "green";
						}else{
							$kehadiran = "";
							$warna = "red";
						}
				?>



			<tr>
				<td><?php echo $row['jam']; ?></td>
				<td><?php echo $row['nama_guru']; ?></td>
				<td><?php echo $row['mapel']; ?></td>
				<td><?php echo $row['kompetensi_dasar']; ?></td>
				<td style="color:<?php echo $warna; ?>"><?php echo $kehadiran; ?></td>
			</tr>	


				<?php	} ?>

			</form>
				
		</table>
		</div>
	</div>

</body>
</html>